"""
Generate a large batch of image samples from a model and save them as a large
numpy array. This can be used to produce samples for FID evaluation.
"""

import argparse
import os

import numpy as np
import torch as th
import torch.distributed as dist
from torchvision.transforms import Compose, Lambda, ToPILImage
from guided_diffusion import dist_util, logger
from guided_diffusion.script_util import (
    NUM_CLASSES,
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    add_dict_to_argparser,
    args_to_dict,
)

reverse_transform = Compose([
     #Lambda(lambda t: (t + 1) / 2),
     Lambda(lambda t: t.permute(1, 2, 0)), # CHW to HWC
     Lambda(lambda t: t * 255.),
     Lambda(lambda t: t.numpy().astype(np.uint8)),
     ToPILImage(),
])


def sample_batch(model,diffusion,args,dirname,cls_id,cycles):
     model_kwargs = {}
     if args.class_cond:
            classes = th.randint(
                low=cls_id, high=cls_id+1, size=(args.batch_size,), device=dist_util.dev()
            )
            model_kwargs["y"] = classes
     sample_fn = (
            diffusion.p_sample_loop if not args.use_ddim else diffusion.ddim_sample_loop
     )
     sample = sample_fn(
            model,
            (args.batch_size, 3, args.image_size, args.image_size),
            clip_denoised=args.clip_denoised,
            model_kwargs=model_kwargs,
     ) 
     print("sample: ",sample.shape)
     sample = sample.cpu().numpy()
     img_min = np.min(sample)
     img_max = np.max(sample)
     img_dx = img_max - img_min
     if args.class_cond:
                classes = classes.cpu().numpy()
     for index in range(args.batch_size):
                generate_image = sample[index]#.reshape(3, args.image_size, args.image_size)
                generate_image = (generate_image-img_min)/img_dx                
                figtest = reverse_transform(th.from_numpy(generate_image))
                label = ""
                if args.class_cond:
                    label = str(classes[index])+"/"
                save_path = dirname+"/"+label
                if not os.path.exists(save_path):
                    os.makedirs(save_path)
                figtest.save(save_path+str(cycles*args.batch_size+index)+".png","png")   

def sample_loop(model,diffusion,args,dirname,cycles):
    all_images = []
    all_labels = []
    for cls_id in range(0,6):
        sample_batch(model,diffusion,args,dirname,cls_id,cycles)
        
        logger.log(f"created {args.batch_size} samples")
        
        
def main():
    args = create_argparser().parse_args()
    print("model_path:"+args.model_path)
    dirname = "samples_tomato2_"+args.model_path.split("/")[-1].split(".pt")[-2].split("model")[-1]

    dist_util.setup_dist()
    
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    logger.configure(dir=dirname)

    logger.log("creating model and diffusion...")
    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )
    model.load_state_dict(
        dist_util.load_state_dict(args.model_path, map_location="cpu")
    )
    model.to(dist_util.dev())
    if args.use_fp16:
        model.convert_to_fp16()
    model.eval()

    logger.log("sampling...")
    for i in range(0,10):
        sample_loop(model,diffusion,args,dirname,i)
    
    dist.barrier()
    logger.log("sampling complete")


def create_argparser():
    defaults = dict(
        clip_denoised=True,
        num_samples=20,
        batch_size=4,
        use_ddim=False,
        model_path="",
    )
    defaults.update(model_and_diffusion_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":
    main()
