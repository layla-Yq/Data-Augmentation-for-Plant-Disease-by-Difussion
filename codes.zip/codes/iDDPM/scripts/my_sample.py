"""
Generate a large batch of image samples from a model and save them as a large
numpy array. This can be used to produce samples for FID evaluation.
"""

import argparse
import os

import numpy as np
import torch as th
import torch.distributed as dist
from torchvision.transforms import Compose, Lambda, ToPILImage
from PIL import Image
from improved_diffusion import dist_util, logger
from improved_diffusion.script_util import (
    NUM_CLASSES,
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    add_dict_to_argparser,
    args_to_dict,
)

reverse_transform = Compose([
     #Lambda(lambda t: (t + 1) / 2),
     Lambda(lambda t: t.permute(1, 2, 0)), # CHW to HWC
     Lambda(lambda t: t * 255.),
     Lambda(lambda t: t.numpy().astype(np.uint8)),
     ToPILImage(),
])


def sample_batch(model,diffusion,args,dirname,cls_id,cycles):
            model_kwargs = {}
            #print("NUM_CLASSES:",NUM_CLASSES)
            if args.class_cond:
                classes = th.randint(
                     low=cls_id, high=cls_id+1, size=(args.batch_size,), device=dist_util.dev()
                )
                print(classes)
                model_kwargs["y"] = classes
            sample_fn = (
                diffusion.p_sample_loop if not args.use_ddim else diffusion.ddim_sample_loop
            )
            sample = sample_fn(
                model,
                (args.batch_size, 3, args.image_size, args.image_size),
                clip_denoised=args.clip_denoised,
                model_kwargs=model_kwargs,
            )
            print("sample: ",sample.shape)
            sample = sample.cpu().numpy()
            img_min = np.min(sample)
            img_max = np.max(sample)
            img_dx = img_max - img_min
            if args.class_cond:
                classes = classes.cpu().numpy()
            for index in range(args.batch_size):
                generate_image = sample[index]#.reshape(3, args.image_size, args.image_size)
                
                
                generate_image = (generate_image-img_min)/img_dx
                
                figtest = reverse_transform(th.from_numpy(generate_image))
            #figtest.show()
            #figtest.save("./sample_images_2/"+str(random_index)+".png","png")
                label = ""
                if args.class_cond:
                    label = str(classes[index])+"/"
                save_path = dirname+"/"+label
                if not os.path.exists(save_path):
                    os.makedirs(save_path)
                figtest.save(save_path+str(cycles*args.batch_size+index)+".png","png")
            #cycles = cycles + 1


def sample_loop(model,diffusion,args,dirname,cycles):
    all_images = []
    all_labels = []
    for cls_id in range(0,3):    
        #cycles = cyc
        #NUM_CLASSES = 38
        #START_CLASS = cls_id
        #END_CLASS = cls_id + 1
        #while len(all_images) * args.batch_size < args.num_samples:
        #while cycles * args.batch_size < args.num_samples:
        sample_batch(model,diffusion,args,dirname,cls_id,cycles)
            
        """
        sample = ((sample + 1) * 127.5).clamp(0, 255).to(th.uint8)
        sample = sample.permute(0, 2, 3, 1)
        #sample = sample.permute(0, 1, 2, 0)
        sample = sample.contiguous()
        
        

        gathered_samples = [th.zeros_like(sample) for _ in range(dist.get_world_size())]
        dist.all_gather(gathered_samples, sample)  # gather not supported with NCCL
        all_images.extend([sample.cpu().numpy() for sample in gathered_samples])
        #all_images.extend([sample for sample in gathered_samples])
        if args.class_cond:
            gathered_labels = [
                th.zeros_like(classes) for _ in range(dist.get_world_size())
            ]
            dist.all_gather(gathered_labels, classes)
            all_labels.extend([labels.cpu().numpy() for labels in gathered_labels])
        """
        #logger.log(f"created {len(all_images) * args.batch_size} samples")
        logger.log(f"created {args.batch_size} samples")
        #return cycles

def main():
    args = create_argparser().parse_args()
    print("model_path:"+args.model_path)
    dirs = args.model_path.split("/")
    dirname = "samples_"+dirs[0].split("_")[-1]+"_"+dirs[1].split(".pt")[-2].split("model")[-1]
    dist_util.setup_dist()
    
    #save_path = dirname+"/"
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    logger.configure(dir=dirname)

    logger.log("creating model and diffusion...")
    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )
    model.load_state_dict(
        dist_util.load_state_dict(args.model_path, map_location="cpu")
    )
    logger.log("device= "+str(dist_util.dev()))
    model.to(dist_util.dev())
    model.eval()

    logger.log("sampling...")
    #cycs = 1
    for i in range(0,64):
        sample_loop(model,diffusion,args,dirname,i)
    """
    arr = np.concatenate(all_images, axis=0)
    arr = arr[: args.num_samples]
    print("arr:",arr.shape)
    if args.class_cond:
        label_arr = np.concatenate(all_labels, axis=0)
        label_arr = label_arr[: args.num_samples]
    if dist.get_rank() == 0:
        
        shape_str = "x".join([str(x) for x in arr.shape])
        out_path = os.path.join(logger.get_dir(), f"samples_{shape_str}.npz")
        logger.log(f"saving to {out_path}")
        if args.class_cond:
            np.savez(out_path, arr, label_arr)
        else:
            #np.savez(out_path, arr)
            for random_index in range(args.num_samples):
                generate_image = arr[random_index]
                print(generate_image)
                img_min = np.min(generate_image)
                img_max = np.max(generate_image)
                img_dx = img_max - img_min
                generate_image = (generate_image-img_min)*255/img_dx
                figtest = Image.fromarray(generate_image.astype(np.uint8))#ToPILImage(generate_image)
                #print(figtest)
                #figtest = reverse_transform(th.from_numpy(generate_image))
                #figtest.show()
                #figtest.save("./sample_images_2/"+str(random_index)+".png","png")
                figtest.save("samples/"+str(random_index)+".png","png")
    """        

    dist.barrier()
    logger.log("sampling complete")


def create_argparser():
    defaults = dict(
        clip_denoised=True,
        num_samples=10,
        batch_size=16,
        use_ddim=False,
        model_path="",
    )
    defaults.update(model_and_diffusion_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":
    main()
