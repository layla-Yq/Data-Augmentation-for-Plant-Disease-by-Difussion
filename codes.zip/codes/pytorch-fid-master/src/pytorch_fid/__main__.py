import pytorch_fid.fid_score

pytorch_fid.fid_score.main()
