import torch
import torch.nn as nn
import tqdm
import torch.optim
#from torchvision.models import *
from torchvision import transforms
from torchvision.transforms import Compose, Lambda, ToPILImage
import datetime
from my_data_loader import *
from model.ResNet import *
from model.VGG import *
#from torchsummary import summary
from sklearn import metrics
from sklearn.model_selection import train_test_split
import seaborn as sns
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, accuracy_score, f1_score, recall_score
import numpy
import random
import os
#os.environ["TF_GPU_ALLOW_GROWTH"]="True"
from torch.utils import data

seed = 0

random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
numpy.random.seed(seed)


dev = (torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu'))
print(f"Training on device {dev}.")

def result_test(real, pred,save_path,train_or_val):
    #save_path = "results/"+save_path
    if not os.path.exists(save_path):
         os.makedirs(save_path)
    print("confuse matrix save to:"+save_path)
    cv_conf = confusion_matrix(real, pred)
    acc = accuracy_score(real, pred)
    precision = precision_score(real, pred, average='micro')
    recall = recall_score(real, pred, average='micro')
    f1 = f1_score(real, pred, average='micro')
    patten = 'test:  acc: %.4f   precision: %.4f   recall: %.4f   f1: %.4f'
    print(patten % (acc, precision, recall, f1,))
    labels11 = ['0', '1','2','3','4','5','6','7','8','9','10','11','12']
    disp = ConfusionMatrixDisplay(confusion_matrix=cv_conf, display_labels=labels11)
    disp.plot(cmap="Blues", values_format='')
    
    plt.savefig(save_path+"ConfusionMatrix_"+train_or_val+".tif", dpi=400)

def init_network(model, method='xavier', exclude='embedding'):
    for name, w in model.named_parameters():
        if exclude not in name:
            if 'weight' in name:
                if method == 'xavier':
                    nn.init.xavier_normal_(w)
                elif method == 'kaiming':
                    nn.init.kaiming_normal_(w)
                else:
                    nn.init.normal_(w)
            elif 'bias' in name:
                nn.init.constant_(w, 0)
            else:
                pass

def plot_history(train,val,save_path):
        save_path = "results/"+save_path
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        xs = []
        
        for i in range(len(train["acc"])):
             xs.append(i)
        plt.plot(xs,train["acc"],label="train_acc")
        plt.plot(xs,val["acc"],label="valid_acc")
        plt.xlabel("iters")
        plt.ylabel("")
        plt.legend()
        plt.savefig(save_path+"/acc.png",dpi=400)
        
        plt.close()
        
        plt.plot(xs,train["loss"],label="train_loss")
        plt.plot(xs,val["loss"],label="valid_loss")
        plt.xlabel("iters")
        plt.ylabel("")
        plt.legend()
        plt.savefig(save_path+"/loss.png",dpi=400)

def validation_all(name,best_model,last_model,train_data,valid_data,data_set):
        validation_2(model=last_model,model_name=name,valid_data=train_data,data_set=data_set,train_or_valid="train")
        validation_2(model=best_model,model_name=name,valid_data=valid_data,data_set=data_set,train_or_valid="valid")
        
def validation(model,valid_data,data_set,train_or_valid):         
        model.eval()
        correct = 0
        total = 0
        print(data_set+"  "+train_or_valid)
        pred = np.array([], dtype=int)
        real = np.array([], dtype=int)
        #with torch.no_grad():
        for i, (images, targets,_) in tqdm.tqdm(enumerate(valid_data), ascii=True, total=len(valid_data)):
               images = images.to(device=dev)
               targets = targets.to(device=dev)
               outputs = model(images)
               outputs = nn.Softmax(dim=-1)(outputs)
               _,predicted = torch.max(outputs,dim=1)
               pred = np.append(pred,predicted.cpu())
               real = np.append(real,targets.cpu())               
               
               total += targets.shape[0]
               correct += int((predicted==targets).sum())
               
        valAcc = correct/total
        print("valAcc:",valAcc)
        
        #result_test(real=real,pred=pred,save_path=data_set,train_or_val=train_or_valid)
        print("\n")


def validation_2(model,model_name,valid_data,data_set,train_or_valid):         
        model.eval()
        correct = 0
        total = 0
        print(data_set+"  "+train_or_valid)
        save_path = "results/"+model_name+"/"+data_set
        if not os.path.exists(save_path):
            os.makedirs(save_path)
            
        pred = np.array([], dtype=int)
        real = np.array([], dtype=int)
        
        predFile = open("results/"+model_name+"/"+data_set+"/all_prediction_"+train_or_valid+".txt","w")
        errFile = open("results/"+model_name+"/"+data_set+"/all_error_"+train_or_valid+".txt","w")
        for i, (images, targets,fnames) in tqdm.tqdm(enumerate(valid_data), ascii=True, total=len(valid_data)):
               images = images.to(device=dev)
               targets = targets.to(device=dev)
               
               outputs = model(images)
               outputs = nn.Softmax(dim=-1)(outputs)
               
               _,predicted = torch.max(outputs,dim=1)
               pred = np.append(pred,predicted.cpu())
               real = np.append(real,targets.cpu())
               
               total += targets.shape[0]
               compare = (predicted==targets)
               correct += int(compare.sum())
               
               outputs = outputs.detach().cpu().numpy()
               predicted = predicted.detach().cpu().numpy()
               targets = targets.detach().cpu().numpy()
             
               for j in range(len(fnames)):
                   if False==compare[j]:
                        errFile.write(str(predicted[j])+" ["+str(targets[j])+"] p:"+str(outputs[j,predicted[j]])+" "+fnames[j]+"\n")
                   
                   if targets[j]<6:
                        predFile.write(str(predicted[j])+" ["+str(targets[j])+"] p: "+str(outputs[j,predicted[j]])+" "+fnames[j]+"\n")
                        
               
        valAcc = correct/total
        #valid_acc.append(valAcc)
        print("valAcc:",valAcc)
        
        result_test(real=real,pred=pred,save_path=save_path,train_or_val=train_or_valid)
        print("\n")
        errFile.close()
        predFile.close()
        


def selection(model,cnn_name,valid_data,data_set,theta):         
        model.eval()
        
        save_path = "selected_samples/"+data_set
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        
        predFile = open(save_path+"/all_prediction.txt","w")
          
        reverse_transform = Compose([
               Lambda(lambda t: t.permute(1, 2, 0)), # CHW to HWC
               Lambda(lambda t: t * 255.),
               Lambda(lambda t: t.numpy().astype(np.uint8)),
               ToPILImage(),
               ])
        for i, (images, targets,fnames) in tqdm.tqdm(enumerate(valid_data), ascii=True, total=len(valid_data)):               
               images = images.to(device=dev)
               targets = targets.to(device=dev)         
               
               outputs = model(images)
               outputs = nn.Softmax(dim=-1)(outputs)               
               _,predicted = torch.max(outputs,dim=1)
               
               
               outputs = outputs.detach().cpu().numpy()
               predicted = predicted.detach().cpu().numpy()
               targets = targets.detach().cpu().numpy()
               
               gimg = images.cpu().numpy()
               
               for j in range(len(fnames)):
                   fn = fnames[j].split("/")
                   fname = fn[-1]   
                   label = fn[-2]
                   img_path = save_path+"/"+label
                   if not os.path.exists(img_path):
                        os.makedirs(img_path) 
                   
                   px =  outputs[j,predicted[j]] 
                                 
                   #if px>theta and not predicted[j]==targets[j]:
                   if px>theta and predicted[j]==targets[j]:
                        figtest = reverse_transform(torch.from_numpy(gimg[j]))                        
                        figtest.save(img_path+"/"+data_set+"_"+label+"_"+fname,"png")
                        predFile.write(str(predicted[j])+" ["+str(targets[j])+"] p: "+str(px)+" "+fname+"\n")
                   
        predFile.close()
         


def training_loop(model, model_name, data_set, suf, train_loader,val_loader):	
	lr = 0.01
	momentum = 0.9
	weight_decay = 0.005
	lr_decay_step = "30,50"
	epoches = 80
	
	save_path = "pretrained_model/"+model_name+"/"+data_set+suf
	if not os.path.exists(save_path):
	   os.makedirs(save_path)	
	
	optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
	
	lr_decay_step = list(map(int, lr_decay_step.split(',')))
	scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=lr_decay_step, gamma=0.1)
	loss_fn = nn.CrossEntropyLoss().to(device=dev)
	
	maxAcc = 0.0
	train = {"acc":[],"loss":[]}
	valid = {"acc":[],"loss":[]}
	for epoch in range(1,epoches+1):
		model.train()
		print("lr: ",optimizer.state_dict()['param_groups'][0]['lr'])
		correct = 0
		total = 0
		loss_train = 0.0
	
		for i, (imgs, labels,_) in tqdm.tqdm(enumerate(train_loader), ascii=True, total=len(train_loader)):
			imgs = imgs.to(device=dev)
			labels = labels.to(device=dev)
			outputs = model(imgs)
			outputs = nn.Softmax(dim=-1)(outputs)
			_,predicted = torch.max(outputs,dim=1)
			loss = loss_fn(outputs,labels)			
			
			optimizer.zero_grad()
			loss.backward()#comput the grad
			optimizer.step()# update the weights
			
			loss_train += loss.item()#the value of loss, loss is a object
			correct += int((predicted==labels).sum())
			total += labels.shape[0]
		trainLos = loss_train/len(train_loader)
		trainAcc = correct/total	
		
		train["loss"].append(trainLos)
		train["acc"].append(trainAcc)	
		#if epoch ==1 or epoch % 10 ==0:
		print('{} Epoch {}, Training loss {}. Training acc {}.'.format(datetime.datetime.now(),epoch, trainLos,trainAcc))
		scheduler.step()
		
		model.eval()
		correct = 0
		total = 0
		loss_val = 0.0
		with torch.no_grad():
			for i, (images, targets,_) in tqdm.tqdm(enumerate(val_loader), ascii=True, total=len(val_loader)):
				images = images.to(device=dev)
				targets = targets.to(device=dev)				
				# compute output
				outputs = model(images)
				outputs = nn.Softmax(dim=-1)(outputs)				
				_,predicted = torch.max(outputs,dim=1)
				loss = loss_fn(outputs,targets)
				loss_val += loss.item()
				
				total += targets.shape[0]				
				correct += int((predicted==targets).sum())
		valAcc = correct/total
		valLoss = loss_val/len(val_loader)
		
		valid["acc"].append(valAcc)
		valid["loss"].append(valLoss)
		
		if valAcc >= maxAcc:
			maxAcc = valAcc
			torch.save(model.state_dict(),save_path+"/"+model_name+"_best.pt")
			print("max acc: ",maxAcc,"\n")
		print("Validation Accuracy: {:.4f}%  Loss:{:.4f}   max_acc: {:.4f}%".format(100*valAcc,valLoss,100*maxAcc))
	
	torch.save(model.state_dict(),save_path+"/"+model_name+"_last.pt")
	
	return train,valid
			
		
def my_summary(model):
	for idx, m in enumerate(model.named_modules()):
		name, module = m[0], m[1]
		print("[",idx,"]",name,":")
		print(module)
	print("end")



classes = 13#27#13
batch_size = 32#256
WID = 64 #224
HEI = 64 #224
model_name = "ResNet18_2"

def my_train(data_set):
    sufix = ""
    print(data_set)
    train_p, val_p= load(dir=data_set,batch_size=batch_size,wid=WID,hei=HEI) 
    loaded_model = ResNet18_2(num_classes=classes).to(device=dev)
    #summary(loaded_model,(3,WID,HEI))
       
    train_info,valid_info =  training_loop(model = loaded_model,model_name = model_name,data_set = data_set,suf=sufix,train_loader = train_p,val_loader = val_p)
    plot_history(train=train_info,val=valid_info,save_path=data_set)

def my_train_2(data_set):
    sufix = "-aug147"
    train_p, val_p= load_2(dir=data_set,batch_size=batch_size,wid=WID,hei=HEI) 
    loaded_model = ResNet18_2(num_classes=classes).to(device=dev)
    #summary(loaded_model,(3,WID,HEI))
       
    train_info,valid_info =  training_loop(model = loaded_model,model_name = model_name,data_set = data_set,suf=sufix,train_loader = train_p,val_loader = val_p)
    plot_history(train=train_info,val=valid_info,save_path=data_set)


def my_valid(data_set):
    sufix = ""
    train_p, val_p= load(dir=data_set,batch_size=batch_size,wid=WID,hei=HEI)
    
    model_path = "pretrained_model/"+model_name+"/"+data_set+sufix
    last_model = ResNet18_2(num_classes=classes).to(device=dev)
    last_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    best_model = ResNet18_2(num_classes=classes).to(device=dev)
    best_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    validation_all(name=model_name,best_model=best_model,last_model=last_model,train_data=train_p,valid_data=val_p,data_set=data_set)

def my_valid_2(data_set):
    sufix = "-aug147"
    train_p, val_p= load(dir=data_set,batch_size=batch_size,wid=WID,hei=HEI)
    
    model_path = "pretrained_model/"+model_name+"/"+data_set+sufix
    last_model = ResNet18_2(num_classes=classes).to(device=dev)
    last_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    best_model = ResNet18_2(num_classes=classes).to(device=dev)
    best_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    validation_all(name=model_name,best_model=best_model,last_model=last_model,train_data=train_p,valid_data=val_p,data_set=data_set)

def my_test():
    data_set = "samples_tomato2_070000/scale_15.0"
    test= load_test_2(dir=data_set,batch_size=batch_size,wid=WID,hei=HEI)
    
    model_path = "pretrained_model/"+model_name+"/YYQ-PLD-natural-aug-1000_all-aug147"
    loaded_model = ResNet18_2(num_classes=classes).to(device=dev)
    loaded_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    
    validation(model=loaded_model,valid_data=test,data_set=data_set,train_or_valid="test")

def my_select(cnn_name,sufix,theta,sample_dir):    
    test_data = load_test_2(dir=sample_dir,batch_size=batch_size,wid=WID,hei=HEI)
    
    model_path = "pretrained_model/"+model_name+"/"+cnn_name+sufix
    loaded_model = ResNet18_2(num_classes=classes).to(device=dev)
    loaded_model.load_state_dict(torch.load(model_path+"/"+model_name+"_best.pt",map_location=dev))
    selection(loaded_model,cnn_name,test_data,sample_dir,theta)


data_set = "YYQ-PLD-natural-i1000-g1000-sel_0.9"
my_train(data_set=data_set)
my_train_2(data_set)
my_valid(data_set)
my_valid_2(data_set)

#my_test()
#my_select(cnn_name=data_set,sufix="-aug147",theta=0.9,sample_dir="samples_tomato2_060000")#0.3


