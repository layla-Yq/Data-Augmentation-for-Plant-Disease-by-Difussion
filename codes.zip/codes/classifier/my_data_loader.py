import os
import tqdm
import torch
import torchvision
from torchvision import transforms
from torchvision.transforms import Compose, Lambda, ToPILImage
from torch.utils.data.sampler import SubsetRandomSampler

import glob
from torch.utils import data
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


# load data
class MyDatasetPro(data.Dataset):
	def __init__(self,img_paths,labels,transform,channels=3):
		self.imgs = img_paths
		self.labels = labels
		self.transforms = transform
		self.channel_num = channels
		
	def __getitem__(self,index):
		img = self.imgs[index];
		label = self.labels[index];
		pil_img = Image.open(img)
		if self.channel_num == 3:
			pil_img = pil_img.convert("RGB")
		else:
			pil_img = pil_img.convert("GRAY")
		
		data = self.transforms(pil_img)
		#print("data:",data.shape)
		return data,label,img
	
	def __len__(self):
		return len(self.imgs)




def load(dir="./data",batch_size=32,wid=64,hei=64):
	all_imgs_path = glob.glob(dir+"/train/*/*")
	all_labels = []
	
	for var in all_imgs_path:
		label = var.split("/")[-2]
		all_labels.append(int(label))	

	all_labels = torch.tensor(all_labels)
	print("len of labels: ",len(all_labels))	
	
	transform1 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
	
	mydataset1 = MyDatasetPro(all_imgs_path,all_labels,transform1)
	
	mydataset = torch.utils.data.ConcatDataset([mydataset1])
	
	train_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=True
	)
	print("train_data_loader len:",len(train_data_loader))
	
	all_imgs_path = glob.glob(dir+"/test/*/*")
	all_labels = []
	for var in all_imgs_path:
		#print(var)
		label = var.split("/")[-2]
		#print(label)
		all_labels.append(int(label))
	

	all_labels = torch.tensor(all_labels)
	transform = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
		
	#BATCH_SIZE = 256
	mydataset = MyDatasetPro(all_imgs_path,all_labels,transform,channels=3)
	test_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=False
	)
	print("test_data_loader len:",len(test_data_loader))

	return train_data_loader,test_data_loader

def load_2(dir="./data",batch_size=32,wid=64,hei=64):
	all_imgs_path = glob.glob(dir+"/train/*/*")
	all_labels = []
	
	for var in all_imgs_path:
		label = var.split("/")[-2]
		all_labels.append(int(label))	

	all_labels = torch.tensor(all_labels)
	print("len of labels: ",len(all_labels))	
	
	transform1 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
	
	transform2 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.RandomHorizontalFlip(p=1.0),
		transforms.ToTensor()])
		
	transform3 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.RandomVerticalFlip(p=1.0),
		transforms.ToTensor()])
	
	transform4 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.RandomRotation(90),
		transforms.ToTensor()])	
	
	transform5 = transforms.Compose([
		transforms.Resize((wid,hei)),		
		transforms.RandomRotation(90),
		transforms.RandomHorizontalFlip(p=1.0),
		transforms.ToTensor()])
	
	transform6 = transforms.Compose([
		transforms.Resize((wid,hei)),		
		transforms.RandomRotation(90),
		transforms.RandomVerticalFlip(p=1.0),
		transforms.ToTensor()])
		
	transform7 = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.RandomRotation(180),
		transforms.ToTensor()])	
	
	transform8 = transforms.Compose([
		transforms.Resize((wid,hei)),		
		transforms.RandomRotation(180),
		transforms.RandomHorizontalFlip(p=1.0),
		transforms.ToTensor()])
	
	transform9 = transforms.Compose([
		transforms.Resize((wid,hei)),		
		transforms.RandomRotation(180),
		transforms.RandomVerticalFlip(p=1.0),
		transforms.ToTensor()]) 
		
	mydataset1 = MyDatasetPro(all_imgs_path,all_labels,transform1)
	mydataset2 = MyDatasetPro(all_imgs_path,all_labels,transform2)
	mydataset3 = MyDatasetPro(all_imgs_path,all_labels,transform3)
	mydataset4 = MyDatasetPro(all_imgs_path,all_labels,transform4)
	mydataset5 = MyDatasetPro(all_imgs_path,all_labels,transform5)
	mydataset6 = MyDatasetPro(all_imgs_path,all_labels,transform6)
	mydataset7 = MyDatasetPro(all_imgs_path,all_labels,transform7)
	mydataset8 = MyDatasetPro(all_imgs_path,all_labels,transform8)
	mydataset9 = MyDatasetPro(all_imgs_path,all_labels,transform9)
	
	mydataset = torch.utils.data.ConcatDataset([mydataset1,
	                                            #mydataset2,
	                                            #mydataset3,
	                                            mydataset4,
	                                            #mydataset5,
	                                            #mydataset6,
	                                            mydataset7,
	                                            #mydataset8,
	                                            #mydataset9,
	                                            #mydataset10,
	                                            #mydataset11,
	                                            #mydataset12
	                                            ])
	
	train_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=True
	)
	print("train_data_loader len:",len(train_data_loader))
	
	all_imgs_path = glob.glob(dir+"/test/*/*")
	all_labels = []
	for var in all_imgs_path:
		#print(var)
		label = var.split("/")[-2]
		#print(label)
		all_labels.append(int(label))
	

	all_labels = torch.tensor(all_labels)
	transform = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
		
	#BATCH_SIZE = 256
	mydataset = MyDatasetPro(all_imgs_path,all_labels,transform,channels=3)
	test_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=False
	)
	print("test_data_loader len:",len(test_data_loader))

	return train_data_loader,test_data_loader


def load_test(dir="./YYQ-PLD-natural",batch_size=32,wid=64,hei=64):	
	all_imgs_path = glob.glob(dir+"/test/*/*")
	all_labels = []
	for var in all_imgs_path:
		#print(var)
		label = var.split("/")[-2]
		#print(label)
		all_labels.append(int(label))
	

	all_labels = torch.tensor(all_labels)
	transform = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
		
	#BATCH_SIZE = 256
	mydataset = MyDatasetPro(all_imgs_path,all_labels,transform,channels=3)
	test_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=False
	)
	print("test_data_loader len:",len(test_data_loader))

	return test_data_loader


def load_test_2(dir="./YYQ-PLD-natural",batch_size=32,wid=64,hei=64):	
	all_imgs_path = glob.glob(dir+"/*/*")
	all_labels = []
	for var in all_imgs_path:
		#print(var)
		label = var.split("/")[-2]
		#print(label)
		all_labels.append(int(label))
	

	all_labels = torch.tensor(all_labels)
	transform = transforms.Compose([
		transforms.Resize((wid,hei)),
		transforms.ToTensor()])
		
	#BATCH_SIZE = 256
	mydataset = MyDatasetPro(all_imgs_path,all_labels,transform,channels=3)
	test_data_loader = data.DataLoader(
		mydataset,
		batch_size=batch_size,
		shuffle=False
	)
	print("test_data_loader len:",len(test_data_loader))

	return test_data_loader

reverse_transform = Compose([
               Lambda(lambda t: t.permute(1, 2, 0)), # CHW to HWC
               Lambda(lambda t: t * 255.),
               Lambda(lambda t: t.numpy().astype(np.uint8)),
               ToPILImage(),
               ])
               
def selection(path1,path2): 
        if not os.path.exists(path2):
            os.makedirs(path2)
            
        data = load_test_2(path1)                
        
        for i, (images, targets,fnames) in tqdm.tqdm(enumerate(data), ascii=True, total=len(valid_data)):
               gimg = images.numpy()
               img_min = np.min(gimg)
               img_max = np.max(gimg)
               img_dx = img_max - img_min
               #fnames = fnames.cpu()     
               gimg = (gimg-img_min)/img_dx          
               for j in range(len(fnames)):
                   fn = fnames[j].split("/")
                   fname = fn[-1].split(".")[-1]+".png" 
                   label = fn[-2]                    
                  
                   figtest = reverse_transform(torch.from_numpy(gimg[j]))                        
                   figtest.save(path2+"/"+label+"_"+fname,"png")
       
 
 #selection("./guided_samples_apple2","./guided_samples_apple2_copy")       
